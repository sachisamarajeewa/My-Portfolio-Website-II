(() => {
  const FRAME_COUNT = 159;
  const FOLDER_PATH = 'Portfolio - img set 01';
  const LERP_FACTOR = 0.08; // Smoothness factor (0.05 - 0.1 gives Apple-like inertia)

  const canvas = document.getElementById('scroll-canvas');
  const ctx = canvas.getContext('2d', { alpha: false });
  const loader = document.getElementById('loader');
  const loaderBar = document.getElementById('loader-bar');
  const loaderText = document.getElementById('loader-text');

  const images = new Array(FRAME_COUNT);
  let loadedCount = 0;
  let targetProgress = 0;
  let currentProgress = 0;
  let currentFrameIndex = -1;
  let isInitialRenderDone = false;

  // Format filename e.g. ezgif-frame-001.jpg
  function getFrameSrc(index) {
    const num = String(index + 1).padStart(3, '0');
    return `${encodeURI(FOLDER_PATH)}/ezgif-frame-${num}.jpg`;
  }

  // Preload all 150 frames
  function preloadImages() {
    for (let i = 0; i < FRAME_COUNT; i++) {
      const img = new Image();
      img.src = getFrameSrc(i);

      img.onload = () => {
        loadedCount++;
        const percent = Math.round((loadedCount / FRAME_COUNT) * 100);
        if (loaderBar) loaderBar.style.width = `${percent}%`;
        if (loaderText) loaderText.textContent = `${percent}%`;

        // Render first frame as soon as it's available
        if (i === 0 && !isInitialRenderDone) {
          isInitialRenderDone = true;
          renderFrame(0);
        }

        if (loadedCount >= FRAME_COUNT) {
          onAllLoaded();
        }
      };

      img.onerror = () => {
        loadedCount++;
        if (loadedCount >= FRAME_COUNT) {
          onAllLoaded();
        }
      };

      images[i] = img;
    }
  }

  function onAllLoaded() {
    setTimeout(() => {
      if (loader) {
        loader.classList.add('hidden');
      }
    }, 200);
  }

  // Find nearest available image if current index isn't ready
  function getLoadedImage(index) {
    if (images[index] && images[index].complete && images[index].naturalWidth > 0) {
      return images[index];
    }
    for (let i = index - 1; i >= 0; i--) {
      if (images[i] && images[i].complete && images[i].naturalWidth > 0) return images[i];
    }
    for (let i = index + 1; i < FRAME_COUNT; i++) {
      if (images[i] && images[i].complete && images[i].naturalWidth > 0) return images[i];
    }
    return null;
  }

  // Render specific frame with crisp cover scaling
  function renderFrame(index) {
    const img = getLoadedImage(index);
    if (!img) return;

    const w = window.innerWidth;
    const h = window.innerHeight;
    const imgRatio = img.naturalWidth / img.naturalHeight;
    const screenRatio = w / h;

    let drawW, drawH, drawX, drawY;

    if (screenRatio > imgRatio) {
      drawW = w;
      drawH = w / imgRatio;
      drawX = 0;
      drawY = (h - drawH) / 2;
    } else {
      drawH = h;
      drawW = h * imgRatio;
      drawX = (w - drawW) / 2;
      drawY = 0;
    }

    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, drawX, drawY, drawW, drawH);
  }

  // Handle high-DPI resize
  function handleResize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = window.innerWidth * dpr;
    canvas.height = window.innerHeight * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    if (currentFrameIndex >= 0) {
      renderFrame(currentFrameIndex);
    }
  }

  // Update target progress from window scroll
  function updateScroll() {
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
    if (maxScroll > 0) {
      targetProgress = Math.min(Math.max(window.scrollY / maxScroll, 0), 1);
    } else {
      targetProgress = 0;
    }
  }

  // Animation loop with smooth LERP damping
  function animationLoop() {
    const diff = targetProgress - currentProgress;
    if (Math.abs(diff) > 0.00001) {
      currentProgress += diff * LERP_FACTOR;
    } else {
      currentProgress = targetProgress;
    }

    const frameFloat = currentProgress * (FRAME_COUNT - 1);
    const frameIndex = Math.min(Math.max(Math.round(frameFloat), 0), FRAME_COUNT - 1);

    if (frameIndex !== currentFrameIndex) {
      currentFrameIndex = frameIndex;
      renderFrame(currentFrameIndex);
    }

    requestAnimationFrame(animationLoop);
  }

  // Event Listeners
  window.addEventListener('resize', handleResize, { passive: true });
  window.addEventListener('scroll', updateScroll, { passive: true });

  // Initialize
  handleResize();
  preloadImages();
  updateScroll();
  requestAnimationFrame(animationLoop);
})();
